# Custom routing environment

This example demonstrates how to route using custom environment. It implements
tabs widget by storing active tab state in the `tab` key in the querysting.
