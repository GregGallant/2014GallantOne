# Artificial router context

This example demonstrates how to create a routing context inside a component and
thus to scope Link component.
