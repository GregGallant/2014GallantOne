# Example: master-detail

We treat URL as an encoding for props. Router decodes props from URL and pass it
further to handler. Handler doesn't know from where it gets props so after the
Router everything is pure React.
