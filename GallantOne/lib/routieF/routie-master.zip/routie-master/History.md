
0.3.2 / 2013-05-03 
==================

  * fix for fallback routes
  * updated deps
  * changed to watch Gruntfile.js
  * removed unused live.js file

0.3.0 / 2012-11-06 
==================

  * initial grunt-mocha integration
  * tweaked timeouts
  * lint
  * added routie.navigate with option for silent: true
  * switched to use dist version for tests
  * fixed #1 - double routing bug

0.2.2 / 2012-10-04 
==================

  * added this.params to callback

0.2.1 / 2012-09-26 
==================

  * fix for passing in param when optional

0.2.0 / 2012-09-25 
==================

  * updated readme for named routes
  * named routes

0.1.1 / 2012-09-18 
==================

  * check current hash when adding a new route

0.1.0 / 2012-09-18 
==================

  * ability to remove routes
  * moved license to separate file
  * allow multiple handlers to watch a route

0.0.1 / 2012-07-17 
==================

  * tweaked readme
  * initial commit
